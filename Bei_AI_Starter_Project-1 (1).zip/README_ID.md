# Be'i AI - starter project

Ini adalah proyek awal aplikasi Be'i AI. UI chat sudah dibuat; untuk jawaban AI sungguhan, backend Cloudflare Worker perlu dipasang.

## Yang sudah ada
- Tampilan chat modern, responsif untuk HP
- Mode gelap/terang
- Riwayat chat tersimpan lokal
- Tombol salin jawaban
- Kerangka backend proxy agar API key tidak ditaruh di APK
- Workflow GitHub Actions untuk membangun APK debug

## 1. Jalankan preview web
Butuh Node.js di komputer atau lingkungan cloud:
```bash
npm install
npm run build
```

## 2. Pasang backend AI
1. Buat akun Cloudflare dan buka Workers & Pages.
2. Buat Worker baru, salin isi `worker/src/index.js`.
3. Tambahkan Secret bernama `GEMINI_API_KEY` berisi API key dari Google AI Studio.
4. Deploy Worker. Catat URL Worker, misalnya `https://bei-ai-api.nama-akun.workers.dev`.
5. Di aplikasi, set URL backend dengan menjalankan di console browser:
```js
beiSetApiUrl("https://URL-WORKER-KAMU")
```
Untuk APK final, URL backend sebaiknya ditanam melalui konfigurasi build, bukan meminta pengguna memasukkannya.

## 3. Build APK dari GitHub Actions
1. Buat repository GitHub baru dan upload semua isi folder proyek ini.
2. Buka tab Actions dan jalankan workflow "Build Be'i AI APK".
3. Setelah selesai, buka hasil run dan unduh artifact `bei-ai-debug-apk`.
4. Ekstrak ZIP artifact untuk mendapatkan `app-debug.apk`.

## Catatan penting
- API key jangan pernah ditulis di kode aplikasi, repository publik, atau APK.
- APK debug cocok untuk uji coba. Untuk rilis Play Store, perlu build release yang ditandatangani dan file AAB.
- Google Play memiliki biaya akun developer dan persyaratan pengujian yang berlaku.
- Paket gratis penyedia AI memiliki kuota dan batas penggunaan yang dapat berubah.
- Sebelum publikasi, tambahkan kebijakan privasi, informasi pengumpulan data, penanganan penyalahgunaan, serta pengujian keamanan.
