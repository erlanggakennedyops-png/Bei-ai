const API_URL = localStorage.getItem('bei_api_url') || 'https://bei-ai-api.erlanggakennedy-ops.workers.dev';

let history = JSON.parse(localStorage.getItem('bei_history') || '[]');
let busy = false;

function save() { localStorage.setItem('bei_history', JSON.stringify(history.slice(-80))); }
function scrollBottom() { chat.scrollTop = chat.scrollHeight; }
function addMessage(role, text) {
  welcome?.remove();
  const row = document.createElement('article');
  row.className = `message ${role}`;
  const avatar = document.createElement('div');
  avatar.className = 'avatar';
  avatar.textContent = role === 'assistant' ? "B'" : 'K';
  const bubble = document.createElement('div');
  bubble.className = 'bubble';
  const content = document.createElement('div');
  content.className = 'content';
  content.textContent = text;
  bubble.append(content);
  if (role === 'assistant') {
    const copy = document.createElement('button');
    copy.className = 'copy';
    copy.textContent = 'Salin';
    copy.addEventListener('click', async () => {
      await navigator.clipboard?.writeText(text);
      copy.textContent = 'Tersalin';
      setTimeout(() => copy.textContent = 'Salin', 1200);
    });
    bubble.append(copy);
  }
  row.append(avatar, bubble);
  chat.append(row);
  scrollBottom();
  return content;
}
function setBusy(value) {
  busy = value;
  sendBtn.disabled = value;
  sendBtn.textContent = value ? '…' : '↑';
}
async function ask(text) {
  if (!text.trim() || busy) return;
  const clean = text.trim();
  history.push({ role: 'user', content: clean });
  addMessage('user', clean);
  input.value = '';
  input.style.height = 'auto';
  save();
  const answerNode = addMessage('assistant', 'Sedang berpikir…');
  setBusy(true);
  try {
    if (!API_URL) throw new Error('API belum disetel. Tambahkan alamat backend Be’i terlebih dahulu.');
    const response = await fetch(`${API_URL.replace(/\/$/, '')}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: history.slice(-20) })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Permintaan gagal.');
    answerNode.textContent = data.reply || 'Aku belum mendapat jawaban. Coba lagi.';
    history.push({ role: 'assistant', content: answerNode.textContent });
    save();
  } catch (err) {
    answerNode.textContent = `Belum terhubung ke otak AI: ${err.message}`;
  } finally {
    setBusy(false);
    scrollBottom();
  }
}
form.addEventListener('submit', e => { e.preventDefault(); ask(input.value); });
input.addEventListener('input', () => {
  input.style.height = 'auto';
  input.style.height = Math.min(input.scrollHeight, 120) + 'px';
});
document.querySelectorAll('.suggestion').forEach(btn => btn.addEventListener('click', () => ask(btn.textContent.replace(/^.{2}\s*/, ''))));
document.querySelector('#newBtn').addEventListener('click', () => {
  history = []; save(); chat.innerHTML = ''; chat.append(welcomeTemplate());
});
function welcomeTemplate() {
  const section = document.createElement('section');
  section.className = 'welcome';
  section.innerHTML = `<div class="orb">B'</div><p class="eyebrow">PERSONAL AI ASSISTANT</p><h1>Halo, aku Be'i.</h1><p class="sub">Teman berpikir, mencari ide, dan menyelesaikan banyak hal. Mau mulai dari mana?</p><div class="suggestions"><button class="suggestion">💡 Beri aku ide bisnis</button><button class="suggestion">✍️ Bantu aku menulis</button><button class="suggestion">🌏 Ajari aku bahasa Jepang</button><button class="suggestion">🧠 Jelaskan sesuatu yang rumit</button></div>`;
  section.querySelectorAll('.suggestion').forEach(btn => btn.addEventListener('click', () => ask(btn.textContent.replace(/^.{2}\s*/, ''))));
  return section;
}
document.querySelector('#themeBtn').addEventListener('click', () => {
  document.body.classList.toggle('dark');
  localStorage.setItem('bei_dark', document.body.classList.contains('dark') ? '1' : '0');
});
if (localStorage.getItem('bei_dark') === '1') document.body.classList.add('dark');
if (history.length) {
  welcome?.remove();
  history.forEach(m => addMessage(m.role, m.content));
}
window.beiSetApiUrl = value => { localStorage.setItem('bei_api_url', value); };
