export default {
  async fetch(request, env) {
    const cors = {
      "Access-Control-Allow-Origin": env.ALLOWED_ORIGIN || "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Content-Type": "application/json"
    };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    const url = new URL(request.url);
    if (url.pathname !== "/api/chat" || request.method !== "POST") {
      return new Response(JSON.stringify({ error: "Not found" }), { status: 404, headers: cors });
    }
    if (!env.GEMINI_API_KEY) return new Response(JSON.stringify({ error: "API key belum dipasang di backend." }), { status: 503, headers: cors });
    try {
      const body = await request.json();
      const messages = Array.isArray(body.messages) ? body.messages.slice(-20) : [];
      const contents = messages.map(m => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: String(m.content || "").slice(0, 12000) }]
      }));
      const upstream = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: "Namamu Be'i, asisten AI yang ramah, jelas, jujur, dan membantu. Jawab terutama dalam bahasa yang digunakan pengguna. Jika tidak yakin, katakan dengan jujur." }] },
          contents,
          generationConfig: { temperature: 0.7, maxOutputTokens: 1200 }
        })
      });
      const result = await upstream.json();
      if (!upstream.ok) return new Response(JSON.stringify({ error: result.error?.message || "Penyedia AI menolak permintaan." }), { status: upstream.status, headers: cors });
      const reply = result.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("") || "Maaf, aku belum bisa menjawab.";
      return new Response(JSON.stringify({ reply }), { headers: cors });
    } catch (e) {
      return new Response(JSON.stringify({ error: "Permintaan tidak valid atau koneksi bermasalah." }), { status: 400, headers: cors });
    }
  }
};